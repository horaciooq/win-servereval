# win-servereval
Este script te ayudara recolectar las evidencias solicitadas en IEECO
Ejecutar el archivo EvalServer.exe con permisos de administrador